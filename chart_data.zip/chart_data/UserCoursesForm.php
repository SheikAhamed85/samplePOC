<?php
//moodleform is defined in formslib.php
require_once("$CFG->libdir/formslib.php");

class UserCoursesForm extends moodleform {
    //Add elements to form
    public function definition() {
        global $CFG,$DB;
        $mform = $this->_form; // Don't forget the underscore!
        $userCountries = array();
        $selectArrayCountry['%']='All Country';
        $selectArrayGender['%']='Any Gender';
        $selectArrayCategory['%']='All Course Category';
        $selectArrayUserType['%']='All User Type';
        
        $userCountries = $DB->get_records_sql('select countryabv,countryname from countries where countryabv in (select country from ec_user)');
        foreach($userCountries as $userCountry) {
            $key = $userCountry->countryabv;
            $value = $userCountry->countryname;
            $selectArrayCountry[$key] = $value;
        }

        $gender = $DB->get_records_sql('select distinct(data) as gender from `ec_user_info_data` where userid in (select id from ec_user)');
        foreach($gender as $selectGender) {
            $key = $selectGender->gender;
            $value = $selectGender->gender;
            $selectArrayGender[$key] = $value;
        }

        $courseCategories = $DB->get_records_sql('select id,name FROM ec_course_categories');
        foreach($courseCategories as $courseCategory) {
            $key = $courseCategory->id;
            $value = $courseCategory->name;
            $selectArrayCategory[$key] = $value;
        }

        $userTypes = $DB->get_records_sql('select id,archetype from ec_role where id in (SELECT roleid FROM `ec_role_assignments` WHERE userid in (select id from ec_user))');
        foreach($userTypes as $userType) {
            $key = $userType->id;
            $value = $userType->archetype;
            $selectArrayUserType[$key] = $value;
        }

        $mform->addElement('html', '<table style="width:100%;"><tr><td><span style="color: #f2623d;"><h4># of users per course</h4></span><br/>');
        $mform->addElement('html', '<table style="width:100%;"><tr><td>');
        $mform->addElement('select', 'country', get_string('country'), $selectArrayCountry);
        $mform->addElement('html', '</td><td>');
        $mform->addElement('select', 'gender', 'Gender', $selectArrayGender);
        $mform->addElement('html', '</td></tr><tr><td>');
        $mform->addElement('select', 'courseCategory', 'Course Category', $selectArrayCategory);
        $mform->addElement('html', '</td><td>');
        $mform->addElement('select', 'userType', 'User Type', $selectArrayUserType);
        $mform->addElement('html', '</td></tr><tr><td>');
        $mform->addElement('date_selector', 'assesstimestart', get_string('from'),array('startyear' => 2017, 'stopyear' => date("Y"),'timezone'  => 99,'optional'  => false));
        $mform->addElement('html', '</td><td>');
        $mform->addElement('date_selector', 'assesstimeend', get_string('to'),array('startyear' => 2017, 'stopyear' => date("Y"),'timezone'  => 99,'optional'  => false));
        $mform->addElement('html', '</td></tr></table>');
        $mform->addElement('html', '</td></tr></table>');
        $mform->addElement('html', '<br/><table style="width:80%;" align="right"><tr><td></td><td>');
        $this->add_action_buttons($cancel = true,'Build Chart');
        $mform->addElement('html', '</td></tr></table><br/>');
    }
    //Custom validation should be added here
    function validation($data, $files) {
        return array();
    }

    /*function getAllCountries() {
        global $DB;
        $sql = 'select countryabv,countryname from countries where countryabv in (select country from ec_user)';
    
        return $DB->get_records_sql($sql);
    }*/
}