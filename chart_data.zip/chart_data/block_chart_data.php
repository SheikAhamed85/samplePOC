<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Block displaying information about current logged-in user.
 *
 * This block can be used as anti cheating measure, you
 * can easily check the logged-in user matches the person
 * operating the computer.
 *
 * @package    block_myprofile
 * @copyright  2010 Remote-Learner.net
 * @author     Olav Jordan <olav.jordan@remote-learner.ca>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Displays the current user's profile information.
 *
 * @copyright  2010 Remote-Learner.net
 * @author     Olav Jordan <olav.jordan@remote-learner.ca>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require_once('UserCoursesForm.php');

class block_chart_data extends block_base {
    /**
     * block initializations
     */
    public function init() {
        $this->title = get_string('pluginname', 'block_chart_data');
    }

    function getMessage() {
      return "Hello World!";
  }

    public function get_content() {
    global $OUTPUT,$CFG,$DB;

    if ($this->content !== null) {
      return $this->content;
    }
    
    $this->content =  new stdClass;
    if (! empty($this->config->text)) {
        $this->content->text = $this->config->text;
    }
    //$this->content->footer = 'Footer here...';
    $mform = new UserCoursesForm();

    //Form processing and displaying is done here
		if ($mform->is_cancelled()) {
			//Handle form cancel operation, if cancel button is present on form
            $this->content->text = 'cancel block';
		} else if ($fromform = $mform->get_data()) {
			//In this case you process validated data. $mform->get_data() returns data posted in form.
            //$this->content->text = $fromform->assesstimestart . '---->'.$fromform->country . '---->'.$fromform->courseCategory . '---->'.$fromform->userType . '---->'.$fromform->gender;
		    $noofusers = array();
        $courses = array();

global $DB;
$userdata= $DB->get_records_sql('SELECT count(*) as users,
course.fullname as course
FROM ec_course as course
JOIN ec_enrol AS en ON en.courseid = course.id
JOIN ec_user_enrolments AS ue ON ue.enrolid = en.id
JOIN ec_user AS user2 ON ue.userid = user2.id
JOIN ec_user_info_data AS ug ON ue.userid = ug.userid
JOIN ec_role_assignments AS ur ON ue.userid = ur.userid
where user2.timecreated >=? and user2.timecreated <? and user2.country like ? and lower(ug.data) like ? and course.category like ? and ur.roleid like ? 
Group by course.fullname',array($fromform->assesstimestart,$fromform->assesstimeend,$fromform->country,strtolower($fromform->gender),$fromform->courseCategory,$fromform->userType));
foreach($userdata as $user) {
    $noofusers[] = $user->users;
    $courses[] = $user->course;
}

$this->content->text = '<frame><!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial;}

/* Style the tab */
.tab {
  overflow: hidden;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: .8375rem;
  color:#6a737b;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #6a737b;
  color: white;
  border: 1px solid #ccc;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #6a737b;
  color: white;
  border: 1px solid #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-top: none;
}
</style>
</head>
<body>

<div class="tab">
  <button class="tablinks" onclick="openCity(event, \'total_courses\')">Total Courses</button>
  <button class="tablinks active" onclick="openCity(event, \'users_per_course\')">Users per Course</button>
  <button class="tablinks" onclick="openCity(event, \'certificates_issued\')">Certificates Issued</button>
  <button class="tablinks" onclick="openCity(event, \'courses_completed\')">Courses Completed</button>
  <button class="tablinks" onclick="openCity(event, \'completion_rate\')">Completion Rate</button>
  <button class="tablinks" onclick="openCity(event, \'completion_duration\')">Completion Duration</button>
</div>

<div id="total_courses" class="tabcontent">
  <p>Total Courses view</p>
</div>

<div id="users_per_course" class="tabcontent" style="display:block;">
  <p>
  <frame>
<!DOCTYPE html>
<html>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
<body>

<canvas id="myChart" style="width:100%;max-width:600px"></canvas>

<script>
var xValues = ["'.implode("\",\"",$courses).'"];
var yValues = ['.implode(",",$noofusers).'];


new Chart("myChart", {
  type: "horizontalBar",
  data: {
  labels: xValues,
  datasets: [{
    backgroundColor: "#0088ff",
    data: yValues
  }]
},
  options: {
    legend: {display: false},
    title: {
      display: true,
      text: "# of users per course"
    },
    scales: {
      xAxes: [{ticks: {min: 10}}],
      yAxes: [{barThickness: 20,maxBarThickness: 20 }],
    }
  }
});
</script>

</body>
</html>
</frame>
  
</p>
</div>

<div id="certificates_issued" class="tabcontent">
  <p>Certificates Issued view</p>
</div>

<div id="courses_completed" class="tabcontent">
  <p>Courses Completed view</p>
</div>

<div id="completion_rate" class="tabcontent">
  <p>Completion Rate view</p>
</div>

<div id="completion_duration" class="tabcontent">
  <p>Completion Duration view</p>
</div>

<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
</script>
   
</body>
</html>
</frame> 
';
} else {
    //$this->content->text = $mform->render();

    $dataCountry['%']='All Country';
    $userCountries = $DB->get_records_sql('select countryabv,countryname from countries where countryabv in (select country from ec_user)');
        foreach($userCountries as $userCountry) {
            $key = $userCountry->countryabv;
            $value = $userCountry->countryname;
            $dataCountry[$key] = $value;
        } 

        $input_data = new stdClass();
        $input_data->name = $dataCountry;

    $this->content->text = $OUTPUT->render_from_template('block_chart_data/chart_data', $input_data);
}

    return $this->content;
}

public function specialization() {
    if (isset($this->config)) {
        if (empty($this->config->title)) {
            $this->title = get_string('defaulttitle', 'block_chart_data');            
        } else {
            $this->title = $this->config->title;
        }

        if (empty($this->config->text)) {
            $this->config->text = get_string('defaulttext', 'block_chart_data');
        }    
    }
}

public function instance_allow_multiple() {
    return true;
  }

}
