<?php
require(__DIR__ . '/../../../config.php');
if($_POST["action"]=='usersPerCourseReport'){ 
    $noofusers = array();
    $courses = array();
global $DB;
$queryCondition='';
if($_POST["country"] != '%'){
    $queryCondition .=' and u.country="'.$_POST["country"].'"';
}

if($_POST["gender"] != '%'){
    $queryCondition .=' and lower(ug.data)="'.strtolower($_POST["gender"]).'"';
}

if($_POST["course_category"] != '%'){
    $queryCondition .=' and c.category='.$_POST["course_category"];
}

if($_POST["user_type"] != '%'){
    $queryCondition .=' and r.roleid='.$_POST["user_type"];
}

$query = 'SELECT COUNT(u.id) AS users, c.fullname AS course
FROM ec_role_assignments AS r
JOIN ec_user AS u on r.userid = u.id
JOIN ec_role AS rn on r.roleid = rn.id
JOIN ec_context AS ctx on r.contextid = ctx.id
JOIN ec_course AS c on ctx.instanceid = c.id
JOIN ec_user_info_data AS ug ON u.id = ug.userid
where DATE_FORMAT(FROM_UNIXTIME(u.timecreated), "%Y-%m-%d") >= ? and DATE_FORMAT(FROM_UNIXTIME(u.timecreated), "%Y-%m-%d") < ? '.$queryCondition.' 
GROUP BY c.fullname';

$userdata= $DB->get_records_sql($query,array($_POST["start"],$_POST["end"]));
foreach($userdata as $user) {
    $noofusers[] = $user->users;
    $courses[] = $user->course;
}

echo '"'.implode("\",\"",$courses).'"'.'|'.implode(",",$noofusers); 
}   